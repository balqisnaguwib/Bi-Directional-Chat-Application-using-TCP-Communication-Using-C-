﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gwiOMI
{
    public partial class Server : Form
    {
        private TcpListener server;
        private List<TcpClient> connectedClients;
        private StreamReader reader;
        private StreamWriter writer;

        public Server()
        {
            InitializeComponent();
            connectedClients = new List<TcpClient>();
        }

        private void Start_Button_Click(object sender, EventArgs e)
        {
            string ipAddress = GetLocalIPAddress();
            IPServer.Text = ipAddress;

            int port = 2708; // Set your desired port number here
            PortServer.Text = port.ToString();

            try
            {
                server = new TcpListener(IPAddress.Parse(ipAddress), port);
                server.Start();

                AppendToTextBox("Waiting for client connection...");

                Task.Run(async () =>
                {
                    while (true)
                    {
                        TcpClient client = await server.AcceptTcpClientAsync();

                        connectedClients.Add(client); // Add the client to the list

                        AppendToTextBox("Client has been connected...");
                        Send_Button.Enabled = true;
                        Import_Button.Enabled = true;

                        _ = Task.Run(() => ReceiveMessages(client)); // Start receiving messages for the newly connected client
                        _ = Task.Run(() => ReceiveImages(client)); // Start receiving images for the newly connected client
                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AppendToTextBox(string message)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<string>(AppendToTextBox), message);
                return;
            }

            ChatServer.AppendText(message + Environment.NewLine);
        }

        private async void Send_Button_Click(object sender, EventArgs e)
        {
            string text = TextBox.Text;
            await SendMessageToClients(text); // Send the message to all connected clients
            AppendToTextBox("Server: " + text);
            TextBox.Clear();
        }

        private async Task SendMessageToClients(string message)
        {
            try
            {
                byte[] messageBytes = Encoding.UTF8.GetBytes(message);

                foreach (var client in connectedClients)
                {
                    NetworkStream stream = client.GetStream();
                    await stream.WriteAsync(messageBytes, 0, messageBytes.Length);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void Import_Button_ClickAsync(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.png, *.jpg, *.jpeg, *.gif, *.bmp) | *.png; *.jpg; *.jpeg; *.gif; *.bmp";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string imagePath = openFileDialog.FileName;
                await SendImageToClients(imagePath); // Send the image to all connected clients
            }
        }

        private async Task SendImageToClients(string imagePath)
        {
            try
            {
                byte[] buffer = File.ReadAllBytes(imagePath);

                foreach (var connectedClient in connectedClients)
                {
                    NetworkStream clientStream = connectedClient.GetStream();
                    await clientStream.WriteAsync(buffer, 0, buffer.Length);
                }

                AppendToTextBox("Server: [Sent an image]");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void ReceiveMessages(TcpClient client)
        {
            try
            {
                using (NetworkStream stream = client.GetStream())
                {
                    byte[] buffer = new byte[client.ReceiveBufferSize];

                    while (true)
                    {
                        int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                        if (bytesRead > 0)
                        {
                            string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                            AppendToChatServer("Client: " + message);

                        }
                        else
                        {
                            // If no bytes are read, the client has disconnected
                            AppendToTextBox("Client has been disconnected...");
                            connectedClients.Remove(client);
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AppendToChatServer(string message)
        {
            if (ChatServer.InvokeRequired)
            {
                Invoke(new Action<string>(AppendToChatServer), message);
            }
            else
            {
                ChatServer.AppendText(message + Environment.NewLine);
            }
        }

        private async void ReceiveImages(TcpClient connectedClient)
        {
            try
            {
                var clientStream = connectedClient.GetStream();

                while (true)
                {
                    byte[] buffer = new byte[connectedClient.ReceiveBufferSize];
                    int bytesRead = await clientStream.ReadAsync(buffer, 0, buffer.Length);
                    if (bytesRead > 0)
                    {
                        using (MemoryStream memoryStream = new MemoryStream(buffer, 0, bytesRead))
                        {
                            Image image = Image.FromStream(memoryStream);
                            Clipboard.SetImage(image);
                            AppendToTextBox("Client: [Received an image]");
                            await SendImageToClients(buffer); // Forward the image to all connected clients
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void Export_Button_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text Files (*.txt) | *.txt";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string chatHistory = ChatServer.Text;

                try
                {
                    using (StreamWriter writer = new StreamWriter(saveFileDialog.FileName))
                    {
                        await writer.WriteAsync(chatHistory);
                    }

                    MessageBox.Show("Chat history exported successfully.", "Export",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Server_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (server != null)
            {
                server.Stop();
            }

            foreach (var connectedClient in connectedClients)
            {
                connectedClient.Close();
            }
        }

        private string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("No network adapters with an IPv4 address found.");
        }
    }
}
