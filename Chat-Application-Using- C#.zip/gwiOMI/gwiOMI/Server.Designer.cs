﻿namespace gwiOMI
{
    partial class Server
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Export_Button = new System.Windows.Forms.Button();
            this.Import_Button = new System.Windows.Forms.Button();
            this.Send_Button = new System.Windows.Forms.Button();
            this.TextBox = new System.Windows.Forms.TextBox();
            this.ChatServer = new System.Windows.Forms.RichTextBox();
            this.Start_Button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.IP = new System.Windows.Forms.Label();
            this.IPServer = new System.Windows.Forms.Label();
            this.PortServer = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Export_Button
            // 
            this.Export_Button.Location = new System.Drawing.Point(636, 393);
            this.Export_Button.Name = "Export_Button";
            this.Export_Button.Size = new System.Drawing.Size(75, 23);
            this.Export_Button.TabIndex = 19;
            this.Export_Button.Text = "EXPORT";
            this.Export_Button.UseVisualStyleBackColor = true;
            this.Export_Button.Click += new System.EventHandler(this.Export_Button_Click);
            // 
            // Import_Button
            // 
            this.Import_Button.Location = new System.Drawing.Point(637, 364);
            this.Import_Button.Name = "Import_Button";
            this.Import_Button.Size = new System.Drawing.Size(75, 23);
            this.Import_Button.TabIndex = 18;
            this.Import_Button.Text = "IMPORT";
            this.Import_Button.UseVisualStyleBackColor = true;
            this.Import_Button.Click += new System.EventHandler(this.Import_Button_ClickAsync);
            // 
            // Send_Button
            // 
            this.Send_Button.Location = new System.Drawing.Point(637, 335);
            this.Send_Button.Name = "Send_Button";
            this.Send_Button.Size = new System.Drawing.Size(75, 23);
            this.Send_Button.TabIndex = 17;
            this.Send_Button.Text = "SEND";
            this.Send_Button.UseVisualStyleBackColor = true;
            this.Send_Button.Click += new System.EventHandler(this.Send_Button_Click);
            // 
            // TextBox
            // 
            this.TextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.TextBox.Location = new System.Drawing.Point(92, 335);
            this.TextBox.Multiline = true;
            this.TextBox.Name = "TextBox";
            this.TextBox.Size = new System.Drawing.Size(522, 81);
            this.TextBox.TabIndex = 16;
            // 
            // ChatServer
            // 
            this.ChatServer.Location = new System.Drawing.Point(92, 67);
            this.ChatServer.Name = "ChatServer";
            this.ChatServer.Size = new System.Drawing.Size(619, 262);
            this.ChatServer.TabIndex = 15;
            this.ChatServer.Text = "";
            // 
            // Start_Button
            // 
            this.Start_Button.Location = new System.Drawing.Point(637, 34);
            this.Start_Button.Name = "Start_Button";
            this.Start_Button.Size = new System.Drawing.Size(75, 23);
            this.Start_Button.TabIndex = 14;
            this.Start_Button.Text = "START";
            this.Start_Button.UseVisualStyleBackColor = true;
            this.Start_Button.Click += new System.EventHandler(this.Start_Button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(409, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "PORT";
            // 
            // IP
            // 
            this.IP.AutoSize = true;
            this.IP.Location = new System.Drawing.Point(88, 39);
            this.IP.Name = "IP";
            this.IP.Size = new System.Drawing.Size(17, 13);
            this.IP.TabIndex = 10;
            this.IP.Text = "IP";
            // 
            // IPServer
            // 
            this.IPServer.AutoSize = true;
            this.IPServer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.IPServer.Location = new System.Drawing.Point(129, 39);
            this.IPServer.Name = "IPServer";
            this.IPServer.Size = new System.Drawing.Size(10, 13);
            this.IPServer.TabIndex = 20;
            this.IPServer.Text = "-";
            // 
            // PortServer
            // 
            this.PortServer.AutoSize = true;
            this.PortServer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.PortServer.Location = new System.Drawing.Point(473, 39);
            this.PortServer.Name = "PortServer";
            this.PortServer.Size = new System.Drawing.Size(10, 13);
            this.PortServer.TabIndex = 21;
            this.PortServer.Text = "-";
            // 
            // Server
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.PortServer);
            this.Controls.Add(this.IPServer);
            this.Controls.Add(this.Export_Button);
            this.Controls.Add(this.Import_Button);
            this.Controls.Add(this.Send_Button);
            this.Controls.Add(this.TextBox);
            this.Controls.Add(this.ChatServer);
            this.Controls.Add(this.Start_Button);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.IP);
            this.Name = "Server";
            this.Text = "Server";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Export_Button;
        private System.Windows.Forms.Button Import_Button;
        private System.Windows.Forms.Button Send_Button;
        private System.Windows.Forms.TextBox TextBox;
        private System.Windows.Forms.RichTextBox ChatServer;
        private System.Windows.Forms.Button Start_Button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label IP;
        private System.Windows.Forms.Label IPServer;
        private System.Windows.Forms.Label PortServer;
    }
}