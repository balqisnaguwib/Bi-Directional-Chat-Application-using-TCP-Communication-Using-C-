﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gwiOMI_client
{
    public partial class CLient : Form
    {
        private TcpClient client;
        private NetworkStream stream;
        private StreamReader reader;
        private StreamWriter writer;

        public CLient()
        {
            InitializeComponent();
        }

        private async void Start_Button_Click(object sender, EventArgs e)
        {
            string ipAddress = IPClient.Text;
            int port = int.Parse(PortClient.Text);

            try
            {
                client = new TcpClient();
                await client.ConnectAsync(IPAddress.Parse(ipAddress), port);

                stream = client.GetStream();
                reader = new StreamReader(stream);
                writer = new StreamWriter(stream) { AutoFlush = true };

                IPClient.Enabled = false;
                PortClient.Enabled = false;
                Connect_Button.Enabled = false;
                Send_Button.Enabled = true;
                Import_Button.Enabled = true;

                ChatClient.AppendText("Client has been connected..." + Environment.NewLine);
                _ = Task.Run(() => ReceiveMessages());
                _ = Task.Run(() => ReceiveImages());
            }
            catch (Exception ex)
            {
                ChatClient.AppendText("Connection failed..." + Environment.NewLine);
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async Task SendMessageToServer(string message)
        {
            try
            {
                await writer.WriteLineAsync(message);
                await writer.FlushAsync(); // Flush the writer to send the message immediately
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private async void Send_Button_Click(object sender, EventArgs e)
        {
            string text = TextBox.Text;
            await SendMessageToServer(text);
            ChatClient.AppendText("Client: " + text + Environment.NewLine);
            TextBox.Clear();
        }

        private async void Import_Button_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.png, *.jpg, *.jpeg, *.gif, *.bmp) | *.png; *.jpg; *.jpeg; *.gif; *.bmp";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string imagePath = openFileDialog.FileName;
                await SendImageToServer(imagePath);
            }
        }

        private async Task SendImageToServer(string imagePath)
        {
            try
            {
                using (FileStream fileStream = File.OpenRead(imagePath))
                {
                    byte[] buffer = new byte[fileStream.Length];
                    await fileStream.ReadAsync(buffer, 0, buffer.Length);
                    await stream.WriteAsync(buffer, 0, buffer.Length);
                }

                ChatClient.AppendText("Client: [Sent an image]" + Environment.NewLine);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void Export_Button_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text Files (*.txt) | *.txt";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string chatHistory = ChatClient.Text;

                try
                {
                    using (StreamWriter writer = new StreamWriter(saveFileDialog.FileName))
                    {
                        await writer.WriteAsync(chatHistory);
                    }

                    MessageBox.Show("Chat history exported successfully.", "Export",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private async void ReceiveMessages()
        {
            try
            {
                while (true)
                {
                    string message = await reader.ReadLineAsync();
                    if (!string.IsNullOrEmpty(message))
                    {
                        if (message.StartsWith("Client: "))
                        {
                            // Message sent by the client itself
                            AppendToChatClient(message);
                        }
                        else
                        {
                            // Message sent by the server
                            AppendToChatClient("Server: " + message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AppendToChatClient(string message)
        {
            if (ChatClient.InvokeRequired)
            {
                ChatClient.Invoke(new Action<string>(AppendToChatClient), message);
            }
            else
            {
                ChatClient.AppendText(message + Environment.NewLine);
            }
        }

        private async void ReceiveImages()
        {
            try
            {
                while (true)
                {
                    byte[] buffer = new byte[client.ReceiveBufferSize];
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                    if (bytesRead > 0)
                    {
                        using (MemoryStream memoryStream = new MemoryStream(buffer, 0, bytesRead))
                        {
                            Image image = Image.FromStream(memoryStream);
                            Clipboard.SetImage(image);
                            ChatClient.AppendText("Server: [Received an image]" + Environment.NewLine);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (reader != null)
            {
                reader.Close();
            }

            if (writer != null)
            {
                writer.Close();
            }

            if (stream != null)
            {
                stream.Close();
            }

            if (client != null)
            {
                client.Close();
            }
        }
    }
}
