﻿using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gwiOMI_server
{
    public partial class Server : Form
    {
        private TcpListener listener;
        private TcpClient client;
        private NetworkStream stream;
        private StreamReader reader;
        private StreamWriter writer;

        private readonly object clipboardLock = new object();

        public Server()
        {
            InitializeComponent();
        }

        private async void Start_Button_Click(object sender, EventArgs e)
        {
            IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
            int port = 12345;

            listener = new TcpListener(ipAddress, port);
            listener.Start();

            IPServer.Text = ipAddress.ToString();
            PortServer.Text = port.ToString();

            AppendToChatServer("Waiting for client to connect...");
            ChatServer.AppendText(Environment.NewLine);

            client = await listener.AcceptTcpClientAsync();
            stream = client.GetStream();
            reader = new StreamReader(stream);
            writer = new StreamWriter(stream) { AutoFlush = true };

            AppendToChatServer("Connection established with the client.");
            ChatServer.AppendText(Environment.NewLine);

            await ReceiveDataFromClient();
        }

        private async Task ReceiveDataFromClient()
        {
            while (client != null && client.Connected)
            {
                try
                {
                    string data = await reader.ReadLineAsync();

                    if (IsImage(data))
                    {
                        byte[] imageBytes = Convert.FromBase64String(data);

                        using (MemoryStream ms = new MemoryStream(imageBytes))
                        {
                            Image receivedImage = Image.FromStream(ms);

                            lock (clipboardLock)
                            {
                                AppendToChatServer("Client: ");
                                Clipboard.SetImage(receivedImage);
                                ChatServer.Paste();
                                AppendToChatServer(Environment.NewLine);
                            }
                        }
                    }
                    else
                    {
                        AppendToChatServer("Client: " + data);
                        ChatServer.AppendText(Environment.NewLine);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while receiving message from the client: " + ex.Message);
                }
            }
        }

        private bool IsImage(string image)
        {
            try
            {
                byte[] imageBytes = Convert.FromBase64String(image);

                using (MemoryStream ms = new MemoryStream(imageBytes))
                {
                    Image.FromStream(ms);
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        private void Send_Button_Click(object sender, EventArgs e)
        {
            if (client != null && client.Connected)
            {
                string message = TextServer.Text;
                AppendToChatServer("Server: " + message);
                ChatServer.AppendText(Environment.NewLine);
                TextServer.Clear();
                writer.WriteLine(message);
            }
        }

        private void Import_Button_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string imagePath = openFileDialog.FileName;
                // Display the image path in TextBox3
                AppendToChatServer("Server: ");

                SendImageToClient(imagePath);
            }
        }

        private void SendImageToClient(string imagePath)
        {
            if (client != null && client.Connected)
            {
                try
                {
                    // Read the image data
                    byte[] imageData = File.ReadAllBytes(imagePath);

                    // Convert the image data to a Base64 string
                    string base64Image = Convert.ToBase64String(imageData);

                    // Send the image data to the client
                    writer.WriteLine(base64Image);
                    writer.Flush();


                    // Set the TextBox1 Text to display the image
                    Image image = Image.FromFile(imagePath);
                    lock (clipboardLock)
                    {
                        Clipboard.SetImage(image);
                        ChatServer.Paste();
                        ChatServer.AppendText(Environment.NewLine);
                    }
                    AppendToChatServer(Environment.NewLine);
                    // Clear the TextBox2 after sending the image
                    TextServer.Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while sending the image: " + ex.Message);
                }
            }
        }

        private void Export_Button_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text Files|*.txt";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = saveFileDialog.FileName;
                File.WriteAllText(filePath, ChatServer.Text);
                MessageBox.Show("Chat history exported successfully!");
            }
        }

        private void AppendToChatServer(string text)
        {
            if (ChatServer.InvokeRequired)
            {
                ChatServer.Invoke(new Action<string>(AppendToChatServer), text);
            }
            else
            {
                ChatServer.AppendText(text + Environment.NewLine);
            }
        }

    }
}
