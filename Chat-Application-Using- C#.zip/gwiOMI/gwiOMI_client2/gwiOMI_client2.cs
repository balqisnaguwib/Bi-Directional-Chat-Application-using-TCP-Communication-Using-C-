﻿using System;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gwiOMI_client2
{
    public partial class gwiOMI_client2 : Form
    {
        private TcpClient client;
        private NetworkStream stream;
        private StreamReader reader;
        private StreamWriter writer;

        private readonly object clipboardLock = new object();

        public gwiOMI_client2()
        {
            InitializeComponent();
        }

        private async void Connect_Button_Click(object sender, EventArgs e)
        {
            if (client == null || !client.Connected)
            {
                string ipAddress = IPClient.Text;
                int port = int.Parse(PortClient.Text);

                try
                {
                    // Connect to the server
                    client = new TcpClient();
                    await client.ConnectAsync(ipAddress, port);
                    stream = client.GetStream();
                    reader = new StreamReader(stream);
                    writer = new StreamWriter(stream) { AutoFlush = true };

                    // Connection established
                    AppendToChatClient("Connection established with the server.");
                    ChatClient.AppendText(Environment.NewLine);
                    await ReceiveDataFromServer();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while connecting to the server: " + ex.Message);
                }
            }
        }

        private void Send_Button_Click(object sender, EventArgs e)
        {
            if (client != null && client.Connected)
            {
                string message = TextClient.Text;

                // Display the message in TextBox3
                AppendToChatClient("Client: " + message);
                ChatClient.AppendText(Environment.NewLine);
                TextClient.Clear();

                // Send the message to the server
                writer.WriteLine(message);
            }
        }

        private void Import_Button_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string imagePath = openFileDialog.FileName;

                // Display the image path in TextBox3
                AppendToChatClient("Client: ");

                // Send the image to the server
                SendImageToServer(imagePath);
            }
        }

        private void Export_Button_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text Files|*.txt";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = saveFileDialog.FileName;

                // Save the chat history to a text file
                File.WriteAllText(filePath, ChatClient.Text);

                MessageBox.Show("Chat history exported successfully!");
            }
        }

        private void AppendToChatClient(string text)
        {
            if (ChatClient.InvokeRequired)
            {
                ChatClient.Invoke(new Action<string>(AppendToChatClient), text);
            }
            else
            {
                ChatClient.AppendText(text + Environment.NewLine);
            }
        }

        private async Task ReceiveDataFromServer()
        {
            while (client != null && client.Connected)
            {
                try
                {
                    string data = await reader.ReadLineAsync();

                    if (IsImage(data))
                    {
                        byte[] imageBytes = Convert.FromBase64String(data);

                        using (MemoryStream ms = new MemoryStream(imageBytes))
                        {
                            Image receivedImage = Image.FromStream(ms);

                            lock (clipboardLock)
                            {
                                AppendToChatClient("Server: ");
                                Clipboard.SetImage(receivedImage);
                                ChatClient.Paste();
                                AppendToChatClient(Environment.NewLine);
                            }
                        }
                        AppendToChatClient(Environment.NewLine);
                    }
                    else
                    {
                        // Display the received text message in TextBox1
                        AppendToChatClient("Server: " + data);
                        AppendToChatClient(Environment.NewLine);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while receiving image from the server: " + ex.Message);
                }
            }
        }

        private bool IsImage(string image)
        {
            try
            {
                byte[] imageBytes = Convert.FromBase64String(image);

                using (MemoryStream ms = new MemoryStream(imageBytes))
                {
                    Image.FromStream(ms);
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        private void SendImageToServer(string imagePath)
        {
            if (client != null && client.Connected)
            {
                try
                {
                    // Read the image data
                    byte[] imageData = File.ReadAllBytes(imagePath);

                    // Convert the image data to a Base64 string
                    string base64Image = Convert.ToBase64String(imageData);

                    // Send the image data to the client
                    writer.WriteLine(base64Image);

                    // Set the TextBox1 Text to display the image
                    Image image = Image.FromFile(imagePath);
                    lock (clipboardLock)
                    {
                        Clipboard.SetImage(image);
                        ChatClient.Paste();
                        ChatClient.AppendText(Environment.NewLine);
                    }

                    // Clear the TextBox2 after sending the image
                    TextClient.Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while sending the image: " + ex.Message);
                }
            }
        }
    }
}
