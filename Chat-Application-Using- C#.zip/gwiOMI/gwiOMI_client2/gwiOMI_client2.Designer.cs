﻿namespace gwiOMI_client2
{
    partial class gwiOMI_client2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PortClient = new System.Windows.Forms.TextBox();
            this.IPClient = new System.Windows.Forms.TextBox();
            this.Export_Button = new System.Windows.Forms.Button();
            this.Import_Button = new System.Windows.Forms.Button();
            this.Send_Button = new System.Windows.Forms.Button();
            this.TextClient = new System.Windows.Forms.TextBox();
            this.ChatClient = new System.Windows.Forms.RichTextBox();
            this.Connect_Button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.IP = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // PortClient
            // 
            this.PortClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.PortClient.Location = new System.Drawing.Point(452, 36);
            this.PortClient.Name = "PortClient";
            this.PortClient.Size = new System.Drawing.Size(162, 20);
            this.PortClient.TabIndex = 51;
            // 
            // IPClient
            // 
            this.IPClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.IPClient.Location = new System.Drawing.Point(111, 36);
            this.IPClient.Name = "IPClient";
            this.IPClient.Size = new System.Drawing.Size(255, 20);
            this.IPClient.TabIndex = 50;
            // 
            // Export_Button
            // 
            this.Export_Button.Location = new System.Drawing.Point(636, 393);
            this.Export_Button.Name = "Export_Button";
            this.Export_Button.Size = new System.Drawing.Size(75, 23);
            this.Export_Button.TabIndex = 49;
            this.Export_Button.Text = "EXPORT";
            this.Export_Button.UseVisualStyleBackColor = true;
            this.Export_Button.Click += new System.EventHandler(this.Export_Button_Click);
            // 
            // Import_Button
            // 
            this.Import_Button.Location = new System.Drawing.Point(637, 364);
            this.Import_Button.Name = "Import_Button";
            this.Import_Button.Size = new System.Drawing.Size(75, 23);
            this.Import_Button.TabIndex = 48;
            this.Import_Button.Text = "IMPORT";
            this.Import_Button.UseVisualStyleBackColor = true;
            this.Import_Button.Click += new System.EventHandler(this.Import_Button_Click);
            // 
            // Send_Button
            // 
            this.Send_Button.Location = new System.Drawing.Point(637, 335);
            this.Send_Button.Name = "Send_Button";
            this.Send_Button.Size = new System.Drawing.Size(75, 23);
            this.Send_Button.TabIndex = 47;
            this.Send_Button.Text = "SEND";
            this.Send_Button.UseVisualStyleBackColor = true;
            this.Send_Button.Click += new System.EventHandler(this.Send_Button_Click);
            // 
            // TextClient
            // 
            this.TextClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.TextClient.Location = new System.Drawing.Point(92, 335);
            this.TextClient.Multiline = true;
            this.TextClient.Name = "TextClient";
            this.TextClient.Size = new System.Drawing.Size(522, 81);
            this.TextClient.TabIndex = 46;
            // 
            // ChatClient
            // 
            this.ChatClient.Location = new System.Drawing.Point(93, 67);
            this.ChatClient.Name = "ChatClient";
            this.ChatClient.Size = new System.Drawing.Size(619, 262);
            this.ChatClient.TabIndex = 45;
            this.ChatClient.Text = "";
            // 
            // Connect_Button
            // 
            this.Connect_Button.Location = new System.Drawing.Point(637, 34);
            this.Connect_Button.Name = "Connect_Button";
            this.Connect_Button.Size = new System.Drawing.Size(75, 23);
            this.Connect_Button.TabIndex = 44;
            this.Connect_Button.Text = "CONNECT";
            this.Connect_Button.UseVisualStyleBackColor = true;
            this.Connect_Button.Click += new System.EventHandler(this.Connect_Button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(409, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 43;
            this.label1.Text = "PORT";
            // 
            // IP
            // 
            this.IP.AutoSize = true;
            this.IP.Location = new System.Drawing.Point(88, 39);
            this.IP.Name = "IP";
            this.IP.Size = new System.Drawing.Size(17, 13);
            this.IP.TabIndex = 42;
            this.IP.Text = "IP";
            // 
            // gwiOMI_client2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.PortClient);
            this.Controls.Add(this.IPClient);
            this.Controls.Add(this.Export_Button);
            this.Controls.Add(this.Import_Button);
            this.Controls.Add(this.Send_Button);
            this.Controls.Add(this.TextClient);
            this.Controls.Add(this.ChatClient);
            this.Controls.Add(this.Connect_Button);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.IP);
            this.Name = "gwiOMI_client2";
            this.Text = "Client";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox PortClient;
        private System.Windows.Forms.TextBox IPClient;
        private System.Windows.Forms.Button Export_Button;
        private System.Windows.Forms.Button Import_Button;
        private System.Windows.Forms.Button Send_Button;
        private System.Windows.Forms.TextBox TextClient;
        private System.Windows.Forms.RichTextBox ChatClient;
        private System.Windows.Forms.Button Connect_Button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label IP;
    }
}

